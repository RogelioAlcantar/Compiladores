#ifndef CODIGO_INTERMEDIO_H
#define CODIGO_INTERMEDIO_H

#include <string.h>

typedef struct _quad
{
	char op[50];
	char arg1[50];
	char arg2[20];
	char res[50];
} quad;

typedef struct _codigo_intermedio
{
	quad items[10000];
	int i;
} codigo_intermedio;

typedef struct _label
{
	int items[1000];
	int i;
} label;

codigo_intermedio CODE;

void init_code();

label crear_lista(int l);

label combinar(label l1, label l2);

void backpatch(label l, int inst);

void print_code();

#endif
