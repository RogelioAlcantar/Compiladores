#ifndef TIPOS_H
#define TIPOS_H

int max(int t1, int t2);

int min(int t1, int t2);

void ampliar(char *fin, char *dir, int t1, int t2);

void reducir(char *fin, char *dir, int t1, int t2);

void nuevaTemporal(char* s);

#endif

