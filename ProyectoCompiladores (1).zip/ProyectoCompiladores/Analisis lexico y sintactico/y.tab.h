#define ESTRUCTURA 257
#define ENT 258
#define REAL 259
#define DREAL 260
#define CAR 261
#define SIN 262
#define NUM 263
#define ID 264
#define DEF 265
#define SI 266
#define MIENTRAS 267
#define HACER 268
#define SEGUN 269
#define ESCRIBIR 270
#define LEER 271
#define DEVOLVER 272
#define PYC 273
#define COMA 274
#define TERMINAR 275
#define CASO 276
#define DOSPUN 277
#define ENTONCES 278
#define PRED 279
#define O 280
#define Y 281
#define NO 282
#define VERDADERO 283
#define FALSO 284
#define CADENA 285
#define CARACTER 286
#define PUNTO 287
#define MAQ 288
#define MEQ 289
#define MEI 290
#define MAI 291
#define DOSMAME 292
#define IGUAL 293
#define NL 294
#define ASIGNACION 295
#define MAS 296
#define MEN 297
#define MUL 298
#define DIV 299
#define MOD 300
#define INICIO 301
#define FIN 302
#define LPAR 303
#define RPAR 304
#define LCOR 305
#define RCOR 306
#define SINO 307
#ifdef YYSTYPE
#undef  YYSTYPE_IS_DECLARED
#define YYSTYPE_IS_DECLARED 1
#endif
#ifndef YYSTYPE_IS_DECLARED
#define YYSTYPE_IS_DECLARED 1
typedef union{

    struct{
    int tipo;
    char numeroCaracter[32];
    }numero;

    struct{
    char truelista[1000];
    char falselista[1000];
	    union{
	    int tipo;
	    char dir[32];
	    }num;
    }relacional;

    struct{
    char truelista[1000];
    char falselista[1000];
    }e_bool;
 
    struct{
    char prueba[1000];
    char nextlist[1000];
    }casos;

    struct{
    	char lista[1000];
    	int num;
    }lista_param;

    struct{
    	char lista[1000];
    	int num;
    }lista_arg;

    struct{
    	char dir[32];
    	int tipo;
    }arreglo;

    struct{
    char estructura[32];
    int tipo;
    }dato_est_sim;

    struct{
    char estructura[32];
    char dir[32];
    int tipo;
    }variable_comp;

    struct{
    char estructura[32];
    char dir[32];
    int tipo;
    int base;
    }variable;

	char sentencia[1000];
	char prueba[1000];
    char id[32];
    int base;
    int tipo;
    

} YYSTYPE;
#endif /* !YYSTYPE_IS_DECLARED */
extern YYSTYPE yylval;
