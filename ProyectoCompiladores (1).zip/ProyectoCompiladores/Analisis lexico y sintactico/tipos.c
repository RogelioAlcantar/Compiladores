#include <stdio.h>
#include <string.h>
#include "tipos.h"

int max(int t1, int t2){
	if(t1 == t2) return t1;
	if(t1 == 0 && t2 == 1) return 1;
	if(t1 == 1 && t2 == 0) return 1;

	if(t1 == 0 && t2 == 2) return 2;
	if(t1 == 2 && t2 == 0) return 2;

	if(t1 == 0 && t2 == 3) return 0;
	if(t1 == 3 && t2 == 0) return 0;

	if(t1 == 1 && t2 == 2) return 2;
	if(t1 == 2 && t2 == 1) return 2;

	if(t1 == 1 && t2 == 3) return 1;
	if(t1 == 3 && t2 == 1) return 1;

	if(t1 == 2 && t2 == 3) return 2;
	if(t1 == 3 && t2 == 2) return 2;
	
	return -1;
}

int min(int t1, int t2){
	if(t1 == t2) return t1;
	if(t1 == 0 && t2 == 1) return 0;
	if(t1 == 1 && t2 == 0) return 0;

	if(t1 == 0 && t2 == 2) return 0;
	if(t1 == 2 && t2 == 0) return 0;

	if(t1 == 0 && t2 == 3) return 3;
	if(t1 == 3 && t2 == 0) return 3;

	if(t1 == 1 && t2 == 2) return 1;
	if(t1 == 2 && t2 == 1) return 1;

	if(t1 == 1 && t2 == 3) return 3;
	if(t1 == 3 && t2 == 1) return 3;

	if(t1 == 2 && t2 == 3) return 3;
	if(t1 == 3 && t2 == 2) return 3;

	return -1;
}

void ampliar(char *fin, char *dir, int t1, int t2){
	if(t1 == t2) strcpy(fin, dir);

	if(t1 == 0 && t2 == 1){
		nuevaTemporal(fin);
		printf("%s = (real)%s\n", fin, dir);
	}

	if(t1 == 0 && t2 == 2){
		nuevaTemporal(fin);
		printf("%s = (dreal)%s\n", fin, dir);
	}

	if(t1 == 3 && t2 == 0){
		nuevaTemporal(fin);
		printf("%s = (ent)%s\n", fin, dir);
	}

	if(t1 == 1 && t2 == 2){
		nuevaTemporal(fin);
		printf("%s = (dreal)%s\n", fin, dir);
	}

	if(t1 == 3 && t2 == 1){
		nuevaTemporal(fin);
		printf("%s = (real)%s\n", fin, dir);
	}

	if(t1 == 3 && t2 == 2){
		nuevaTemporal(fin);
		printf("%s = (dreal)%s\n", fin, dir);
	}
}
	
void reducir(char *fin, char *dir, int t1, int t2){
	if(t1 == t2) strcpy(fin, dir);

	if(t1 == 1 && t2 == 0){
		nuevaTemporal(fin);
		printf("%s = (ent)%s\n", fin, dir);
	}

	if(t1 == 2 && t2 == 0){
		nuevaTemporal(fin);
		printf("%s = (ent)%s\n", fin, dir);
	}

	if(t1 == 0 && t2 == 3){
		nuevaTemporal(fin);
		printf("%s = (car)%s\n", fin, dir);
	}

	if(t1 == 2 && t2 == 1){
		nuevaTemporal(fin);
		printf("%s = (real)%s\n", fin, dir);
	}

	if(t1 == 1 && t2 == 3){
		nuevaTemporal(fin);
		printf("%s = (car)%s\n", fin, dir);
	}

	if(t1 == 2 && t2 == 3){
		nuevaTemporal(fin);
		printf("%s = (car)%s\n", fin, dir);
	}
}

void nuevaTemporal(char* s){
	static int num = 0;
	sprintf(s, "t%d", num++);
}