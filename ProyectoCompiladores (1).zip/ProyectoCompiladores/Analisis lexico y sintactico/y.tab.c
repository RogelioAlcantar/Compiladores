/* original parser id follows */
/* yysccsid[] = "@(#)yaccpar	1.9 (Berkeley) 02/21/93" */
/* (use YYMAJOR/YYMINOR for ifdefs dependent on parser version) */

#define YYBYACC 1
#define YYMAJOR 1
#define YYMINOR 9
#define YYPATCH 20140715

#define YYEMPTY        (-1)
#define yyclearin      (yychar = YYEMPTY)
#define yyerrok        (yyerrflag = 0)
#define YYRECOVERING() (yyerrflag != 0)
#define YYENOMEM       (-2)
#define YYEOF          0
#define YYPREFIX "yy"

#define YYPURE 0

#line 2 "parse1.y"
#include <stdio.h>	
#include <string.h>	
#include <stdlib.h> 
#include <stdbool.h>
#include "tipos.h"
#include "codigo_intermedio.h"
#include "tabla_simbolos.h"
#include "tabla_tipo.h"

extern int yylex();
extern int yylineno;
extern char* yytext;
void yyerror(char *s);
int posicionTablaTipo;
int tipoGBL = 0;
int baseGBL;
int tipoDirGBL;
int dirGBL;
int dirGeneral = 0;
char IDGBL[100];
int valorArreglo = 4;

int idST = 0;

int structGBL = 0;

TSTACK *stackTipos;

SYMTAB generalSimbolos;

TYPTAB *generalTipos;

void iniciarStacks();
#line 36 "parse1.y"
#ifdef YYSTYPE
#undef  YYSTYPE_IS_DECLARED
#define YYSTYPE_IS_DECLARED 1
#endif
#ifndef YYSTYPE_IS_DECLARED
#define YYSTYPE_IS_DECLARED 1
typedef union{

    struct{
    int tipo;
    char numeroCaracter[32];
    }numero;

    struct{
    char truelista[1000];
    char falselista[1000];
	    union{
	    int tipo;
	    char dir[32];
	    }num;
    }relacional;

    struct{
    char truelista[1000];
    char falselista[1000];
    }e_bool;
 
    struct{
    char prueba[1000];
    char nextlist[1000];
    }casos;

    struct{
    	char lista[1000];
    	int num;
    }lista_param;

    struct{
    	char lista[1000];
    	int num;
    }lista_arg;

    struct{
    	char dir[32];
    	int tipo;
    }arreglo;

    struct{
    char estructura[32];
    int tipo;
    }dato_est_sim;

    struct{
    char estructura[32];
    char dir[32];
    int tipo;
    }variable_comp;

    struct{
    char estructura[32];
    char dir[32];
    int tipo;
    int base;
    }variable;

	char sentencia[1000];
	char prueba[1000];
    char id[32];
    int base;
    int tipo;
    

} YYSTYPE;
#endif /* !YYSTYPE_IS_DECLARED */
#line 130 "y.tab.c"

/* compatibility with bison */
#ifdef YYPARSE_PARAM
/* compatibility with FreeBSD */
# ifdef YYPARSE_PARAM_TYPE
#  define YYPARSE_DECL() yyparse(YYPARSE_PARAM_TYPE YYPARSE_PARAM)
# else
#  define YYPARSE_DECL() yyparse(void *YYPARSE_PARAM)
# endif
#else
# define YYPARSE_DECL() yyparse(void)
#endif

/* Parameters sent to lex. */
#ifdef YYLEX_PARAM
# define YYLEX_DECL() yylex(void *YYLEX_PARAM)
# define YYLEX yylex(YYLEX_PARAM)
#else
# define YYLEX_DECL() yylex(void)
# define YYLEX yylex()
#endif

/* Parameters sent to yyerror. */
#ifndef YYERROR_DECL
#define YYERROR_DECL() yyerror(const char *s)
#endif
#ifndef YYERROR_CALL
#define YYERROR_CALL(msg) yyerror(msg)
#endif

extern int YYPARSE_DECL();

#define ESTRUCTURA 257
#define ENT 258
#define REAL 259
#define DREAL 260
#define CAR 261
#define SIN 262
#define NUM 263
#define ID 264
#define DEF 265
#define SI 266
#define MIENTRAS 267
#define HACER 268
#define SEGUN 269
#define ESCRIBIR 270
#define LEER 271
#define DEVOLVER 272
#define PYC 273
#define COMA 274
#define TERMINAR 275
#define CASO 276
#define DOSPUN 277
#define ENTONCES 278
#define PRED 279
#define O 280
#define Y 281
#define NO 282
#define VERDADERO 283
#define FALSO 284
#define CADENA 285
#define CARACTER 286
#define PUNTO 287
#define MAQ 288
#define MEQ 289
#define MEI 290
#define MAI 291
#define DOSMAME 292
#define IGUAL 293
#define NL 294
#define ASIGNACION 295
#define MAS 296
#define MEN 297
#define MUL 298
#define DIV 299
#define MOD 300
#define INICIO 301
#define FIN 302
#define LPAR 303
#define RPAR 304
#define LCOR 305
#define RCOR 306
#define SINO 307
#define YYERRCODE 256
typedef short YYINT;
static const YYINT yylhs[] = {                           -1,
   24,    0,   23,   23,   23,    7,    8,   16,   16,   16,
   16,   16,    6,    6,   26,   26,   25,   25,    2,    2,
    1,    1,    5,    3,    4,    4,   10,   10,    9,    9,
    9,    9,    9,    9,    9,    9,    9,    9,    9,    9,
   11,   11,   15,   15,   14,   14,   14,   14,   14,   14,
   13,   13,   13,   13,   13,   13,   13,   12,   12,   12,
   12,   12,   12,   12,   12,   12,   12,   17,   18,   18,
   18,   19,   19,   20,   20,   22,   22,   21,   21,
};
static const YYINT yylen[] = {                            2,
    0,    3,    4,    4,    0,    4,    2,    1,    1,    1,
    1,    1,    4,    0,    3,    1,   11,    0,    1,    1,
    3,    1,    2,    2,    3,    0,    2,    1,    5,    7,
    5,    5,    8,    4,    3,    3,    2,    3,    2,    3,
    5,    4,    3,    0,    3,    3,    2,    1,    1,    1,
    3,    3,    3,    3,    3,    3,    1,    3,    3,    3,
    3,    3,    3,    1,    1,    1,    1,    2,    1,    1,
    3,    3,    0,    3,    4,    1,    0,    3,    1,
};
static const YYINT yydefred[] = {                         1,
    0,    0,    0,    8,    9,   10,   11,   12,    0,    0,
    0,    0,    0,   16,    0,    0,    0,    7,    0,    2,
    0,    0,    0,    0,    0,    0,    6,    4,   15,    3,
    0,    0,   13,    0,    0,    0,    0,    0,   22,    0,
    0,    0,   23,    0,   24,   21,    0,    0,    0,   25,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
   28,    0,    0,    0,    0,   68,    0,    0,   65,    0,
   49,   50,   66,   67,    0,    0,    0,    0,   64,    0,
    0,    0,    0,    0,   37,    0,   39,    0,    0,   27,
    0,    0,    0,    0,    0,    0,    0,   47,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,   35,   36,   38,   40,
   17,    0,    0,   71,   74,   72,    0,   63,    0,    0,
    0,    0,   62,    0,    0,    0,    0,    0,    0,    0,
    0,   46,    0,    0,    0,   34,    0,   75,   29,    0,
   31,   32,    0,    0,    0,    0,   30,    0,    0,    0,
    0,    0,   33,    0,   43,   41,
};
static const YYINT yydgoto[] = {                          1,
   36,   37,   38,   45,   39,   18,    9,   10,   61,   62,
  156,   76,   77,   78,  160,   11,   79,   66,   67,   68,
   93,   94,   12,    2,   20,   15,
};
static const YYINT yysindex[] = {                         0,
    0,   68, -294,    0,    0,    0,    0,    0, -224, -224,
 -288, -215,   68,    0, -174, -169, -181,    0,    2,    0,
 -218,   68, -177,   68, -210, -157,    0,    0,    0,    0,
 -288, -192,    0,  140,    0, -158, -184, -122,    0, -149,
    2, -155,    0, -160,    0,    0,   68, -149,  -16,    0,
 -245, -260, -260,  -16, -146, -232,  -88, -244,  -95,  -16,
    0, -178, -115, -232, -232,    0, -101, -117,    0, -260,
    0,    0,    0,    0, -232,  211,   64,   20,    0, -266,
  -76,  -88, -138,  -63,    0, -104,    0,  -90, -215,    0,
 -232,  211,  -60,  -86,  -19,  -45, -232,    0,  202, -232,
 -232, -232, -232, -232, -232, -232, -232, -232, -232, -232,
  -16, -260, -260,  -16, -260,  -84,    0,    0,    0,    0,
    0,  -70, -232,    0,    0,    0,  197,    0, -173, -173,
  -78,  -78,    0,  223,  -47, -141, -108,  -68,  -68, -241,
  -43,    0,  -65, -225,  -11,    0,  211,    0,    0,  -16,
    0,    0,  -18,  -27,   19,    4,    0,   11,   14,  -10,
  -16,  -16,    0,  -18,    0,    0,
};
static const YYINT yyrindex[] = {                         0,
    0,    9,    0,    0,    0,    0,    0,    0,    0,    0,
 -224,  286,   -9,    0,    0,    0,    0,    0,    0,    0,
    0,    1,    0,    1,    0,    0,    0,    0,    0,    0,
 -224,    0,    0,    0, -258,   -5,    0,    0,    0,   31,
    0,    0,    0,    0,    0,    0,  111,   31,    0,    0,
 -159,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    6,    0,    0, -125,  -91,    0,    0,
    0,    0,    0,    0,    0,  116, -229,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,  286,    0,
    0, -247,   15,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,   43,   70,
  -57,   16,    0,  204,  200,  177,  173,  142,  148,    0,
 -170,    0,    0,    0,    0,    0, -240,    0,    0,    0,
    0,    0,    0,    0,    0,   35,    0,    0,    0,    0,
    0,    0,    0, -267,    0,    0,
};
static const YYINT yygindex[] = {                         0,
    0,    0,    0,  270,  300,  311,    0,  326,  -44,    0,
  182,  -28,  263,  -32,    0,   44,  -49,    0,    0,    0,
    0,    0,   55,    0,  275,  355,
};
#define YYTABLESIZE 516
static const YYINT yytable[] = {                         63,
    5,  114,   69,   51,   63,   12,   13,   84,    5,   81,
   63,   42,   63,  112,  113,   88,   17,   90,   69,   51,
   80,   70,   71,   72,   73,   74,   79,   83,   85,   86,
   69,   51,  116,   78,   42,   92,   95,   98,   48,   14,
   73,   74,   75,   48,   12,   20,   99,  152,   48,   19,
   48,   48,   73,   74,  112,  113,   79,   64,   75,   65,
  149,   63,  122,   78,   63,  150,  140,   21,  127,  143,
   75,  129,  130,  131,  132,  133,   28,   40,   30,  141,
  142,   25,  144,   27,   40,   51,   29,   52,   53,   54,
   55,   56,   57,   58,  147,   31,   59,   45,   22,   23,
   63,   49,   45,   24,   23,  154,   32,   45,   73,   45,
   34,   63,   63,   73,   73,   41,  164,  165,   73,   42,
   73,   73,   60,   89,  102,  103,  104,   73,   73,   73,
   73,   73,   73,   73,  117,   73,   73,   73,   73,   73,
   73,   43,   69,   48,   73,   47,   73,   69,   69,  108,
  109,  110,   69,   44,   69,   69,   82,  100,  101,  102,
  103,  104,   69,   69,   69,   69,   69,   69,  119,   69,
   69,   69,   69,   69,   69,   51,   70,   87,   69,   91,
   69,   70,   70,  109,  110,   96,   70,   97,   70,   70,
  115,  100,  101,  102,  103,  104,   70,   70,   70,   70,
   70,   70,  146,   70,   70,   70,   70,   70,   70,  118,
   60,  120,   70,  123,   70,   60,   60,  124,  126,  145,
   60,  104,   60,   60,  110,  100,  101,  102,  103,  104,
   60,   60,   60,   60,   60,   60,  151,  113,   60,   60,
   60,   60,  107,  108,  109,  110,   60,   51,   60,   52,
   53,   54,   55,   56,   57,   58,  153,  155,   59,    4,
    5,    6,    7,    8,    5,    5,    5,    5,    5,    5,
    5,    5,    5,    5,  157,    5,  100,  101,  102,  103,
  104,  158,  159,   61,   60,   18,  125,  161,   61,   61,
  162,  163,    5,   61,   26,   61,   61,  111,   19,  112,
  113,    5,    5,   61,   61,   61,   61,   61,   61,   77,
   58,   61,   61,   61,   61,   58,   58,   50,   76,   61,
   58,   61,   58,   58,    3,    4,    5,    6,    7,    8,
   58,   58,   58,   58,   58,   58,   44,   59,   58,   58,
   46,   33,   59,   59,   26,  166,   58,   59,   58,   59,
   59,  105,  106,  107,  108,  109,  110,   59,   59,   59,
   59,   59,   59,  121,   16,   59,   59,  134,  135,  136,
  137,  138,  139,   59,    5,   59,    5,    5,    5,    5,
    5,    5,    5,   57,    0,    5,    0,    0,   57,    0,
    0,    0,    0,   57,    0,   57,   57,    4,    5,    6,
    7,   35,    0,   57,   57,   57,   57,   57,   57,   52,
    0,    5,    0,    0,   52,   51,    0,    0,    0,   52,
   51,   52,   52,    0,    0,   51,    0,   51,   51,   52,
   52,   52,   52,   52,    0,   51,   51,   51,   51,   51,
   56,    0,    0,    0,   55,   56,    0,    0,    0,   55,
   56,    0,   56,   56,   55,    0,   55,   55,    0,    0,
   56,   56,   56,   56,   55,   55,   55,   54,    0,    0,
    0,   53,   54,    0,    0,    0,   53,   54,    0,   54,
   54,   53,    0,   53,   53,    0,    0,   54,   54,    0,
    0,   53,  100,  101,  102,  103,  104,  100,  101,  102,
  103,  104,  148,    0,    0,  128,  100,  101,  102,  103,
  104,  106,  107,  108,  109,  110,
};
static const YYINT yycheck[] = {                         49,
    0,  268,  263,  264,   54,  264,  301,   57,    0,   54,
   60,  279,   62,  280,  281,   60,  305,   62,  263,  264,
   53,  282,  283,  284,  285,  286,  274,   56,  273,   58,
  263,  264,   82,  274,  302,   64,   65,   70,  268,  264,
  285,  286,  303,  273,  303,  304,   75,  273,  278,  265,
  280,  281,  285,  286,  280,  281,  304,  303,  303,  305,
  302,  111,   91,  304,  114,  307,  111,   13,   97,  114,
  303,  100,  101,  102,  103,  104,   22,   34,   24,  112,
  113,  263,  115,  302,   41,  264,  264,  266,  267,  268,
  269,  270,  271,  272,  123,  306,  275,  268,  273,  274,
  150,   47,  273,  273,  274,  150,  264,  278,  268,  280,
  303,  161,  162,  273,  274,  274,  161,  162,  278,  304,
  280,  281,  301,  302,  298,  299,  300,  287,  288,  289,
  290,  291,  292,  293,  273,  295,  296,  297,  298,  299,
  300,  264,  268,  304,  304,  301,  306,  273,  274,  291,
  292,  293,  278,  303,  280,  281,  303,  296,  297,  298,
  299,  300,  288,  289,  290,  291,  292,  293,  273,  295,
  296,  297,  298,  299,  300,  264,  268,  273,  304,  295,
  306,  273,  274,  292,  293,  287,  278,  305,  280,  281,
  267,  296,  297,  298,  299,  300,  288,  289,  290,  291,
  292,  293,  273,  295,  296,  297,  298,  299,  300,  273,
  268,  302,  304,  274,  306,  273,  274,  304,  264,  304,
  278,  300,  280,  281,  293,  296,  297,  298,  299,  300,
  288,  289,  290,  291,  292,  293,  302,  281,  296,  297,
  298,  299,  290,  291,  292,  293,  304,  264,  306,  266,
  267,  268,  269,  270,  271,  272,  268,  276,  275,  258,
  259,  260,  261,  262,  264,  265,  266,  267,  268,  269,
  270,  271,  272,  265,  302,  275,  296,  297,  298,  299,
  300,  263,  279,  268,  301,    0,  306,  277,  273,  274,
  277,  302,  302,  278,  264,  280,  281,  278,  304,  280,
  281,  301,  302,  288,  289,  290,  291,  292,  293,  304,
  268,  296,  297,  298,  299,  273,  274,   48,  304,  304,
  278,  306,  280,  281,  257,  258,  259,  260,  261,  262,
  288,  289,  290,  291,  292,  293,  302,  268,  296,  297,
   41,   31,  273,  274,   19,  164,  304,  278,  306,  280,
  281,  288,  289,  290,  291,  292,  293,  288,  289,  290,
  291,  292,  293,   89,   10,  296,  297,  105,  106,  107,
  108,  109,  110,  304,  264,  306,  266,  267,  268,  269,
  270,  271,  272,  268,   -1,  275,   -1,   -1,  273,   -1,
   -1,   -1,   -1,  278,   -1,  280,  281,  258,  259,  260,
  261,  262,   -1,  288,  289,  290,  291,  292,  293,  268,
   -1,  301,   -1,   -1,  273,  268,   -1,   -1,   -1,  278,
  273,  280,  281,   -1,   -1,  278,   -1,  280,  281,  288,
  289,  290,  291,  292,   -1,  288,  289,  290,  291,  292,
  268,   -1,   -1,   -1,  268,  273,   -1,   -1,   -1,  273,
  278,   -1,  280,  281,  278,   -1,  280,  281,   -1,   -1,
  288,  289,  290,  291,  288,  289,  290,  268,   -1,   -1,
   -1,  268,  273,   -1,   -1,   -1,  273,  278,   -1,  280,
  281,  278,   -1,  280,  281,   -1,   -1,  288,  289,   -1,
   -1,  288,  296,  297,  298,  299,  300,  296,  297,  298,
  299,  300,  306,   -1,   -1,  304,  296,  297,  298,  299,
  300,  289,  290,  291,  292,  293,
};
#define YYFINAL 1
#ifndef YYDEBUG
#define YYDEBUG 0
#endif
#define YYMAXTOKEN 307
#define YYUNDFTOKEN 336
#define YYTRANSLATE(a) ((a) > YYMAXTOKEN ? YYUNDFTOKEN : (a))
#if YYDEBUG
static const char *const yyname[] = {

"end-of-file",0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,"ESTRUCTURA","ENT","REAL","DREAL",
"CAR","SIN","NUM","ID","DEF","SI","MIENTRAS","HACER","SEGUN","ESCRIBIR","LEER",
"DEVOLVER","PYC","COMA","TERMINAR","CASO","DOSPUN","ENTONCES","PRED","O","Y",
"NO","VERDADERO","FALSO","CADENA","CARACTER","PUNTO","MAQ","MEQ","MEI","MAI",
"DOSMAME","IGUAL","NL","ASIGNACION","MAS","MEN","MUL","DIV","MOD","INICIO",
"FIN","LPAR","RPAR","LCOR","RCOR","SINO",0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,"illegal-symbol",
};
static const char *const yyrule[] = {
"$accept : programa",
"$$1 :",
"programa : $$1 declaraciones funciones",
"declaraciones : tipo lista_var PYC declaraciones",
"declaraciones : tipo_registro lista_var PYC declaraciones",
"declaraciones :",
"tipo_registro : ESTRUCTURA INICIO declaraciones FIN",
"tipo : base tipo_arreglo",
"base : ENT",
"base : REAL",
"base : DREAL",
"base : CAR",
"base : SIN",
"tipo_arreglo : LCOR NUM RCOR tipo_arreglo",
"tipo_arreglo :",
"lista_var : lista_var COMA ID",
"lista_var : ID",
"funciones : DEF tipo ID LPAR argumentos RPAR INICIO declaraciones sentencias FIN funciones",
"funciones :",
"argumentos : lista_arg",
"argumentos : SIN",
"lista_arg : lista_arg COMA arg",
"lista_arg : arg",
"arg : tipo_arg ID",
"tipo_arg : base param_arr",
"param_arr : LPAR RPAR param_arr",
"param_arr :",
"sentencias : sentencias sentencia",
"sentencias : sentencia",
"sentencia : SI e_bool ENTONCES sentencia FIN",
"sentencia : SI e_bool ENTONCES sentencia SINO sentencia FIN",
"sentencia : MIENTRAS e_bool HACER sentencia FIN",
"sentencia : HACER sentencia MIENTRAS e_bool PYC",
"sentencia : SEGUN LPAR variable RPAR HACER casos predeterminado FIN",
"sentencia : variable ASIGNACION expresion PYC",
"sentencia : ESCRIBIR expresion PYC",
"sentencia : LEER variable PYC",
"sentencia : DEVOLVER PYC",
"sentencia : DEVOLVER expresion PYC",
"sentencia : TERMINAR PYC",
"sentencia : INICIO sentencia FIN",
"casos : CASO NUM DOSPUN sentencia casos",
"casos : CASO NUM DOSPUN sentencia",
"predeterminado : PRED DOSPUN sentencia",
"predeterminado :",
"e_bool : e_bool O e_bool",
"e_bool : e_bool Y e_bool",
"e_bool : NO e_bool",
"e_bool : relacional",
"e_bool : VERDADERO",
"e_bool : FALSO",
"relacional : relacional IGUAL relacional",
"relacional : relacional DOSMAME relacional",
"relacional : relacional MAQ relacional",
"relacional : relacional MEQ relacional",
"relacional : relacional MEI relacional",
"relacional : relacional MAI relacional",
"relacional : expresion",
"expresion : expresion MAS expresion",
"expresion : expresion MEN expresion",
"expresion : expresion MUL expresion",
"expresion : expresion DIV expresion",
"expresion : expresion MOD expresion",
"expresion : LPAR expresion RPAR",
"expresion : variable",
"expresion : NUM",
"expresion : CADENA",
"expresion : CARACTER",
"variable : ID variable_comp",
"variable_comp : dato_est_sim",
"variable_comp : arreglo",
"variable_comp : LPAR parametros RPAR",
"dato_est_sim : dato_est_sim PUNTO ID",
"dato_est_sim :",
"arreglo : LCOR expresion RCOR",
"arreglo : arreglo LCOR expresion RCOR",
"parametros : lista_param",
"parametros :",
"lista_param : lista_param COMA expresion",
"lista_param : expresion",

};
#endif

int      yydebug;
int      yynerrs;

int      yyerrflag;
int      yychar;
YYSTYPE  yyval;
YYSTYPE  yylval;

/* define the initial stack-sizes */
#ifdef YYSTACKSIZE
#undef YYMAXDEPTH
#define YYMAXDEPTH  YYSTACKSIZE
#else
#ifdef YYMAXDEPTH
#define YYSTACKSIZE YYMAXDEPTH
#else
#define YYSTACKSIZE 10000
#define YYMAXDEPTH  10000
#endif
#endif

#define YYINITSTACKSIZE 200

typedef struct {
    unsigned stacksize;
    YYINT    *s_base;
    YYINT    *s_mark;
    YYINT    *s_last;
    YYSTYPE  *l_base;
    YYSTYPE  *l_mark;
} YYSTACKDATA;
/* variables for the parser stack */
static YYSTACKDATA yystack;
#line 751 "parse1.y"

void yyerror(char *s){
	printf("%s, linea: %d en el token: %s \n",s, yylineno, yytext);
}

void iniciarStacks(){
	
	
	
	stackTipos  = init_type_tab_stack();

	generalTipos = init_type_tab();

	TYP *tipo0 = init_type();
	tipo0->id = 0;
	strcpy(tipo0->nombre, "ent");
	tipo0->tam = 4;
	
	TYP *tipo1 = init_type();
	tipo1->id = 1;
	strcpy(tipo1->nombre, "real");
	tipo1->tam = 4;
	
	TYP *tipo2 = init_type();
	tipo2->id = 2;
	strcpy(tipo2->nombre, "dreal");
	tipo2->tam = 8;
	
	TYP *tipo3 = init_type();
	tipo3->id = 3;
	strcpy(tipo3->nombre, "char");
	tipo3->tam = 1;

	TYP *tipo4 = init_type();
	tipo4->id = 4;
	strcpy(tipo4->nombre, "sin");
	tipo4->tam = 0;
	
	posicionTablaTipo = tipo4->id;


	append_type(generalTipos, tipo0);
	append_type(generalTipos, tipo1);
	append_type(generalTipos, tipo2);
	append_type(generalTipos, tipo3);
	append_type(generalTipos, tipo4);
	
	push_tst(stackTipos, generalTipos);

	
	


}

void nuevoIndice(char* s){
	static int num = 0;
	sprintf(s, "i%d", num++);
}
void nuevoIndiceLista(char* s){
	static int num = 0;
	sprintf(s, "iL%d", num++);
}


#line 620 "y.tab.c"

#if YYDEBUG
#include <stdio.h>		/* needed for printf */
#endif

#include <stdlib.h>	/* needed for malloc, etc */
#include <string.h>	/* needed for memset */

/* allocate initial stack or double stack size, up to YYMAXDEPTH */
static int yygrowstack(YYSTACKDATA *data)
{
    int i;
    unsigned newsize;
    YYINT *newss;
    YYSTYPE *newvs;

    if ((newsize = data->stacksize) == 0)
        newsize = YYINITSTACKSIZE;
    else if (newsize >= YYMAXDEPTH)
        return YYENOMEM;
    else if ((newsize *= 2) > YYMAXDEPTH)
        newsize = YYMAXDEPTH;

    i = (int) (data->s_mark - data->s_base);
    newss = (YYINT *)realloc(data->s_base, newsize * sizeof(*newss));
    if (newss == 0)
        return YYENOMEM;

    data->s_base = newss;
    data->s_mark = newss + i;

    newvs = (YYSTYPE *)realloc(data->l_base, newsize * sizeof(*newvs));
    if (newvs == 0)
        return YYENOMEM;

    data->l_base = newvs;
    data->l_mark = newvs + i;

    data->stacksize = newsize;
    data->s_last = data->s_base + newsize - 1;
    return 0;
}

#if YYPURE || defined(YY_NO_LEAKS)
static void yyfreestack(YYSTACKDATA *data)
{
    free(data->s_base);
    free(data->l_base);
    memset(data, 0, sizeof(*data));
}
#else
#define yyfreestack(data) /* nothing */
#endif

#define YYABORT  goto yyabort
#define YYREJECT goto yyabort
#define YYACCEPT goto yyaccept
#define YYERROR  goto yyerrlab

int
YYPARSE_DECL()
{
    int yym, yyn, yystate;
#if YYDEBUG
    const char *yys;

    if ((yys = getenv("YYDEBUG")) != 0)
    {
        yyn = *yys;
        if (yyn >= '0' && yyn <= '9')
            yydebug = yyn - '0';
    }
#endif

    yynerrs = 0;
    yyerrflag = 0;
    yychar = YYEMPTY;
    yystate = 0;

#if YYPURE
    memset(&yystack, 0, sizeof(yystack));
#endif

    if (yystack.s_base == NULL && yygrowstack(&yystack) == YYENOMEM) goto yyoverflow;
    yystack.s_mark = yystack.s_base;
    yystack.l_mark = yystack.l_base;
    yystate = 0;
    *yystack.s_mark = 0;

yyloop:
    if ((yyn = yydefred[yystate]) != 0) goto yyreduce;
    if (yychar < 0)
    {
        if ((yychar = YYLEX) < 0) yychar = YYEOF;
#if YYDEBUG
        if (yydebug)
        {
            yys = yyname[YYTRANSLATE(yychar)];
            printf("%sdebug: state %d, reading %d (%s)\n",
                    YYPREFIX, yystate, yychar, yys);
        }
#endif
    }
    if ((yyn = yysindex[yystate]) && (yyn += yychar) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yychar)
    {
#if YYDEBUG
        if (yydebug)
            printf("%sdebug: state %d, shifting to state %d\n",
                    YYPREFIX, yystate, yytable[yyn]);
#endif
        if (yystack.s_mark >= yystack.s_last && yygrowstack(&yystack) == YYENOMEM)
        {
            goto yyoverflow;
        }
        yystate = yytable[yyn];
        *++yystack.s_mark = yytable[yyn];
        *++yystack.l_mark = yylval;
        yychar = YYEMPTY;
        if (yyerrflag > 0)  --yyerrflag;
        goto yyloop;
    }
    if ((yyn = yyrindex[yystate]) && (yyn += yychar) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yychar)
    {
        yyn = yytable[yyn];
        goto yyreduce;
    }
    if (yyerrflag) goto yyinrecovery;

    YYERROR_CALL("syntax error");

    goto yyerrlab;

yyerrlab:
    ++yynerrs;

yyinrecovery:
    if (yyerrflag < 3)
    {
        yyerrflag = 3;
        for (;;)
        {
            if ((yyn = yysindex[*yystack.s_mark]) && (yyn += YYERRCODE) >= 0 &&
                    yyn <= YYTABLESIZE && yycheck[yyn] == YYERRCODE)
            {
#if YYDEBUG
                if (yydebug)
                    printf("%sdebug: state %d, error recovery shifting\
 to state %d\n", YYPREFIX, *yystack.s_mark, yytable[yyn]);
#endif
                if (yystack.s_mark >= yystack.s_last && yygrowstack(&yystack) == YYENOMEM)
                {
                    goto yyoverflow;
                }
                yystate = yytable[yyn];
                *++yystack.s_mark = yytable[yyn];
                *++yystack.l_mark = yylval;
                goto yyloop;
            }
            else
            {
#if YYDEBUG
                if (yydebug)
                    printf("%sdebug: error recovery discarding state %d\n",
                            YYPREFIX, *yystack.s_mark);
#endif
                if (yystack.s_mark <= yystack.s_base) goto yyabort;
                --yystack.s_mark;
                --yystack.l_mark;
            }
        }
    }
    else
    {
        if (yychar == YYEOF) goto yyabort;
#if YYDEBUG
        if (yydebug)
        {
            yys = yyname[YYTRANSLATE(yychar)];
            printf("%sdebug: state %d, error recovery discards token %d (%s)\n",
                    YYPREFIX, yystate, yychar, yys);
        }
#endif
        yychar = YYEMPTY;
        goto yyloop;
    }

yyreduce:
#if YYDEBUG
    if (yydebug)
        printf("%sdebug: state %d, reducing by rule %d (%s)\n",
                YYPREFIX, yystate, yyn, yyrule[yyn]);
#endif
    yym = yylen[yyn];
    if (yym)
        yyval = yystack.l_mark[1-yym];
    else
        memset(&yyval, 0, sizeof yyval);
    switch (yyn)
    {
case 1:
#line 173 "parse1.y"
	{
				iniciarStacks();
				imprimir(&generalSimbolos);
			}
break;
case 2:
#line 176 "parse1.y"
	{print_tstack(stackTipos); }
break;
case 3:
#line 179 "parse1.y"
	{
				tipoGBL = yystack.l_mark[-3].tipo;
			}
break;
case 4:
#line 183 "parse1.y"
	{
				tipoGBL = yystack.l_mark[-3].tipo;
			}
break;
case 6:
#line 189 "parse1.y"
	{
					yyval.tipo = tipoGBL;
					SYM s;
					char nom[32];
					sprintf(nom, "stuct%d", structGBL);
					structGBL += 1;
		            strcpy(s.id, nom);
			        s.tipo = tipoGBL;
			        s.dir = dirGBL;
			        strcpy(s.var, "struct");
			        s.numArgumentos = 0;
			        dirGBL = dirGBL + s.dir;
			        insertar(&generalSimbolos, s);
				}
break;
case 7:
#line 205 "parse1.y"
	{
			baseGBL = yystack.l_mark[-1].base;
			yyval.tipo = yystack.l_mark[0].tipo;
		}
break;
case 8:
#line 210 "parse1.y"
	{yyval.base = 0;}
break;
case 9:
#line 210 "parse1.y"
	{yyval.base = 1;}
break;
case 10:
#line 210 "parse1.y"
	{yyval.base = 2;}
break;
case 11:
#line 210 "parse1.y"
	{yyval.base = 3;}
break;
case 12:
#line 210 "parse1.y"
	{yyval.base = 4;}
break;
case 13:
#line 213 "parse1.y"
	{	
					yyval.tipo = yystack.l_mark[0].tipo;
					if(yystack.l_mark[-2].numero.tipo == 0){
						if(yystack.l_mark[-2].numero.numeroCaracter != ""){
							
							TYP *tipo4 = init_type();
							tipo4->id = posicionTablaTipo + 1;
							strcpy(tipo4->nombre, "array");
							tipo4->tam =  valorArreglo * atoi(yystack.l_mark[-2].numero.numeroCaracter);
							tipo4->tb.is_est = 0;
							tipo4->tb.tipo.tipo = posicionTablaTipo;
							valorArreglo = tipo4->tam;
							posicionTablaTipo = tipo4->id;

							append_type(generalTipos, tipo4);

							pop_tst(stackTipos);
							
							push_tst(stackTipos, generalTipos);


						}else{
							yyerror("El numero del arreglo no es compatible");
						}
						

					}else{
						yyerror("El numero del arreglo no es compatible");
					}
					
				}
break;
case 14:
#line 245 "parse1.y"
	{
					yyval.tipo = baseGBL;
				}
break;
case 15:
#line 250 "parse1.y"
	{	
				if(!getID(&generalSimbolos, yystack.l_mark[0].id)){
		   			SYM s;
				    strcpy(s.id, yystack.l_mark[0].id);
				    s.tipo = tipoGBL;
				    s.dir = dirGBL;
				    strcpy(s.var, "var");
				    s.numArgumentos = 0;
				    dirGBL = dirGBL + s.dir;
				    insertar(&generalSimbolos, s);
				    
				}
			}
break;
case 16:
#line 264 "parse1.y"
	{
										if(!getID(&generalSimbolos, yystack.l_mark[0].id)){
					                    	SYM s;
								            strcpy(s.id, yystack.l_mark[0].id);
									        s.tipo = tipoGBL;
									        s.dir = dirGBL;
									        strcpy(s.var, "var");
									        s.numArgumentos = 0;
									        dirGBL = dirGBL + s.dir;
									        insertar(&generalSimbolos, s);
									        
										}
								}
break;
case 17:
#line 280 "parse1.y"
	{
				if(!getID(&generalSimbolos, yystack.l_mark[-8].id)){
					SYM s;
		            strcpy(s.id, yystack.l_mark[-8].id);
			        s.tipo = tipoGBL;
			        s.dir = dirGBL;
			        strcpy(s.var, "def");
			        s.numArgumentos = yystack.l_mark[-6].lista_arg.num;
			        dirGBL = dirGBL + s.dir;
			        insertar(&generalSimbolos, s);
				}else{
					yyerror("El id de la def ya existe");
				}
			}
break;
case 19:
#line 296 "parse1.y"
	{
			strcpy(yyval.lista_arg.lista, yystack.l_mark[0].lista_arg.lista);
			yyval.lista_arg.num = yystack.l_mark[0].lista_arg.num + 1;
			}
break;
case 20:
#line 301 "parse1.y"
	{
				strcpy(yyval.lista_arg.lista, "NULO");
				yyval.lista_arg.num = 0;
			}
break;
case 21:
#line 307 "parse1.y"
	{
			strcpy(yyval.lista_arg.lista, yystack.l_mark[-2].lista_arg.lista);
			yyval.lista_arg.num = yystack.l_mark[-2].lista_arg.num + 1;
			}
break;
case 22:
#line 312 "parse1.y"
	{
				char nuevo[1000];
				strcpy(yyval.lista_arg.lista, nuevo);
				yyval.lista_arg.num = yystack.l_mark[0].tipo;
			}
break;
case 23:
#line 319 "parse1.y"
	{
		yyval.tipo = yystack.l_mark[-1].tipo;
		if(!getID(&generalSimbolos, yystack.l_mark[0].id)){
			SYM s;
            strcpy(s.id, yystack.l_mark[0].id);
	        s.tipo = yystack.l_mark[-1].tipo;
	        s.dir = dirGBL;
	        strcpy(s.id, "arg");
	        s.numArgumentos = 0;
	        dirGBL = dirGBL + s.dir;
	        insertar(&generalSimbolos, s);

			
		}else{
			yyerror("El id ya fue declarado");
		}
	}
break;
case 24:
#line 338 "parse1.y"
	{	
			yyval.tipo = yystack.l_mark[0].tipo;
			baseGBL = yystack.l_mark[-1].base;

		}
break;
case 25:
#line 344 "parse1.y"
	{ 			yyval.tipo = yystack.l_mark[0].tipo;
											
											TYP *tipo4 = init_type();
											tipo4->id = posicionTablaTipo + 1;
											strcpy(tipo4->nombre, "array");
											tipo4->tam =  0;
											tipo4->tb.is_est = 0;
											tipo4->tb.tipo.tipo = yystack.l_mark[0].tipo;
											valorArreglo = tipo4->tam;
											posicionTablaTipo = tipo4->id;

											append_type(generalTipos, tipo4);

											pop_tst(stackTipos);
											
											push_tst(stackTipos, generalTipos);


								}
break;
case 26:
#line 364 "parse1.y"
	{
				yyval.tipo = baseGBL;
			}
break;
case 27:
#line 369 "parse1.y"
	{
				char nuevo[1000];
				strcpy(yyval.sentencia,nuevo);
			}
break;
case 28:
#line 374 "parse1.y"
	{
				char nuevo[1000];
				strcpy(yyval.sentencia,nuevo);
			}
break;
case 29:
#line 380 "parse1.y"
	{
				char nuevo[1000];
				strcpy(yyval.sentencia,nuevo);
		}
break;
case 30:
#line 385 "parse1.y"
	{
				char nuevo [1000];
				strcpy(yyval.sentencia,nuevo);
		}
break;
case 31:
#line 390 "parse1.y"
	{
			strcpy(yyval.sentencia,yystack.l_mark[-3].e_bool.falselista);
		}
break;
case 32:
#line 394 "parse1.y"
	{
			strcpy(yyval.sentencia,yystack.l_mark[-1].e_bool.falselista);
		}
break;
case 33:
#line 398 "parse1.y"
	{
			strcpy(yyval.sentencia,yystack.l_mark[-2].casos.nextlist);
		}
break;
case 34:
#line 402 "parse1.y"
	{

			char nuevo [1000];
			reducir(nuevo, yystack.l_mark[-1].numero.numeroCaracter, yystack.l_mark[-1].numero.tipo, yystack.l_mark[-3].variable.tipo);
			if(strcmp(yystack.l_mark[-3].variable.estructura, "true") != 0){
				printf("%d ( %s ) = %s", yystack.l_mark[-3].variable.base, yystack.l_mark[-3].variable.dir, nuevo);
			}
		}
break;
case 35:
#line 411 "parse1.y"
	{
			char nuevo [1000];
			strcpy(yyval.sentencia, nuevo);
			printf("\nescribir %s\n", yystack.l_mark[-1].numero.numeroCaracter);
		}
break;
case 36:
#line 417 "parse1.y"
	{
			char nuevo [1000];
			strcpy(yyval.sentencia, nuevo);
			printf("\nleer %s\n", yystack.l_mark[-1].variable.dir);
		}
break;
case 37:
#line 423 "parse1.y"
	{
			char nuevo [1000];
			strcpy(yyval.sentencia, nuevo);
			printf("\ndevolver\n");
		}
break;
case 38:
#line 429 "parse1.y"
	{
			char nuevo [1000];
			strcpy(yyval.sentencia, nuevo);
			printf("\ndevolver %s\n", yystack.l_mark[-1].numero.numeroCaracter);
			char i1[100], indice1[100];
			nuevoIndice(i1);
			strcpy(indice1, i1);
			nuevoIndiceLista(i1);
			printf("goto %s\n", indice1);

		}
break;
case 39:
#line 441 "parse1.y"
	{
			char nuevo [1000];
			strcpy(yyval.sentencia, nuevo);
			printf("\nterminar\n");
		}
break;
case 40:
#line 447 "parse1.y"
	{
			strcpy(yyval.sentencia, yystack.l_mark[-1].sentencia);
		}
break;
case 41:
#line 452 "parse1.y"
	{
			strcpy(yyval.casos.nextlist,yystack.l_mark[-1].sentencia);
			strcpy(yyval.casos.prueba,yystack.l_mark[-1].sentencia);
		}
break;
case 42:
#line 457 "parse1.y"
	{	
			char nuevo[1000];
			strcpy(yyval.casos.prueba,nuevo);
			strcpy(yyval.casos.nextlist,yystack.l_mark[0].sentencia);
		}
break;
case 43:
#line 465 "parse1.y"
	{
					char nuevo[1000];
					strcpy(yyval.prueba, nuevo);
				}
break;
case 44:
#line 470 "parse1.y"
	{
					char nuevo[1000];
					strcpy(yyval.prueba, nuevo);
				}
break;
case 47:
#line 479 "parse1.y"
	{
			strcpy(yyval.e_bool.truelista, yystack.l_mark[0].e_bool.falselista);
			strcpy(yyval.e_bool.falselista, yystack.l_mark[0].e_bool.truelista);
		}
break;
case 48:
#line 484 "parse1.y"
	{
			strcpy(yyval.e_bool.truelista, yystack.l_mark[0].relacional.truelista);
			strcpy(yyval.e_bool.falselista, yystack.l_mark[0].relacional.falselista);
		}
break;
case 49:
#line 489 "parse1.y"
	{
			char i1[100], indice[100];
			nuevoIndice(i1);
			strcpy(indice, i1);
			nuevoIndiceLista(i1);
			strcpy(yyval.e_bool.truelista, i1);
			printf("\ngoto %s\n", indice);
		}
break;
case 50:
#line 498 "parse1.y"
	{
			char i1[100], indice[100];
			nuevoIndice(i1);
			strcpy(indice, i1);
			nuevoIndiceLista(i1);
			strcpy(yyval.e_bool.falselista, i1);
			printf("\ngoto %s\n", indice);
		}
break;
case 51:
#line 508 "parse1.y"
	{
				char i1[100], i2[100], indice1[100], indice2[100];
				nuevoIndice(i1);
				nuevoIndice(i2);
				strcpy(indice1, i1);
				strcpy(indice2, i2);
				nuevoIndiceLista(i1);
				nuevoIndiceLista(i2);
				strcpy(yyval.relacional.truelista, i1);
				strcpy(yyval.relacional.falselista, i2);
				printf("\nif %s = %s goto %s\n", yystack.l_mark[-2].relacional.num.dir, yystack.l_mark[0].relacional.num.dir, indice1);
				printf("goto %s\n", indice2);

			}
break;
case 52:
#line 523 "parse1.y"
	{
				char i1[100], i2[100], indice1[100], indice2[100];
				nuevoIndice(i1);
				nuevoIndice(i2);
				strcpy(indice1, i1);
				strcpy(indice2, i2);
				nuevoIndiceLista(i1);
				nuevoIndiceLista(i2);
				strcpy(yyval.relacional.truelista, i1);
				strcpy(yyval.relacional.falselista, i2);
				printf("\nif %s <> %s goto %s\n", yystack.l_mark[-2].relacional.num.dir, yystack.l_mark[0].relacional.num.dir, indice1);
				printf("goto %s\n", indice2);

			}
break;
case 53:
#line 538 "parse1.y"
	{
				char i1[100], i2[100], indice1[100], indice2[100];
				nuevoIndice(i1);
				nuevoIndice(i2);
				strcpy(indice1, i1);
				strcpy(indice2, i2);
				nuevoIndiceLista(i1);
				nuevoIndiceLista(i2);
				strcpy(yyval.relacional.truelista, i1);
				strcpy(yyval.relacional.falselista, i2);
				printf("\nif %s > %s goto %s\n", yystack.l_mark[-2].relacional.num.dir, yystack.l_mark[0].relacional.num.dir, indice1);
				printf("goto %s\n", indice2);

			}
break;
case 54:
#line 553 "parse1.y"
	{
				char i1[100], i2[100], indice1[100], indice2[100];
				nuevoIndice(i1);
				nuevoIndice(i2);
				strcpy(indice1, i1);
				strcpy(indice2, i2);
				nuevoIndiceLista(i1);
				nuevoIndiceLista(i2);
				strcpy(yyval.relacional.truelista, i1);
				strcpy(yyval.relacional.falselista, i2);
				printf("\nif %s < %s goto %s\n", yystack.l_mark[-2].relacional.num.dir, yystack.l_mark[0].relacional.num.dir, indice1);
				printf("goto %s\n", indice2);

			}
break;
case 55:
#line 568 "parse1.y"
	{
				char i1[100], i2[100], indice1[100], indice2[100];
				nuevoIndice(i1);
				nuevoIndice(i2);
				strcpy(indice1, i1);
				strcpy(indice2, i2);
				nuevoIndiceLista(i1);
				nuevoIndiceLista(i2);
				strcpy(yyval.relacional.truelista, i1);
				strcpy(yyval.relacional.falselista, i2);
				printf("\nif %s <= %s goto %s\n", yystack.l_mark[-2].relacional.num.dir, yystack.l_mark[0].relacional.num.dir, indice1);
				printf("goto %s\n", indice2);

			}
break;
case 56:
#line 583 "parse1.y"
	{
				char i1[100], i2[100], indice1[100], indice2[100];
				nuevoIndice(i1);
				nuevoIndice(i2);
				strcpy(indice1, i1);
				strcpy(indice2, i2);
				nuevoIndiceLista(i1);
				nuevoIndiceLista(i2);
				strcpy(yyval.relacional.truelista, i1);
				strcpy(yyval.relacional.falselista, i2);
				printf("\nif %s >= %s goto %s\n", yystack.l_mark[-2].relacional.num.dir, yystack.l_mark[0].relacional.num.dir, indice1);
				printf("goto %s\n", indice2);

			}
break;
case 57:
#line 598 "parse1.y"
	{
				yyval.relacional.num.tipo = yystack.l_mark[0].numero.tipo;
				strcpy(yyval.relacional.num.dir, yystack.l_mark[0].numero.numeroCaracter);

			}
break;
case 58:
#line 605 "parse1.y"
	{
					char dir1[32], dir2[32];
					nuevaTemporal(yyval.numero.numeroCaracter);
					yyval.numero.tipo = max(yystack.l_mark[-2].numero.tipo, yystack.l_mark[0].numero.tipo);
					ampliar(dir1, yystack.l_mark[-2].numero.numeroCaracter, yystack.l_mark[-2].numero.tipo, yyval.numero.tipo);
					ampliar(dir2, yystack.l_mark[0].numero.numeroCaracter, yystack.l_mark[0].numero.tipo, yyval.numero.tipo);
					printf("\n%s = %s + %s\n", yyval.numero.numeroCaracter, dir1, dir2);
				}
break;
case 59:
#line 614 "parse1.y"
	{
					char dir1[32], dir2[32];
					nuevaTemporal(yyval.numero.numeroCaracter);
					yyval.numero.tipo = max(yystack.l_mark[-2].numero.tipo, yystack.l_mark[0].numero.tipo);
					ampliar(dir1, yystack.l_mark[-2].numero.numeroCaracter, yystack.l_mark[-2].numero.tipo, yyval.numero.tipo);
					ampliar(dir2, yystack.l_mark[0].numero.numeroCaracter, yystack.l_mark[0].numero.tipo, yyval.numero.tipo);
					printf("\n%s = %s - %s\n", yyval.numero.numeroCaracter, dir1, dir2);
				}
break;
case 60:
#line 623 "parse1.y"
	{
					char dir1[32], dir2[32];
					nuevaTemporal(yyval.numero.numeroCaracter);
					yyval.numero.tipo = max(yystack.l_mark[-2].numero.tipo, yystack.l_mark[0].numero.tipo);
					ampliar(dir1, yystack.l_mark[-2].numero.numeroCaracter, yystack.l_mark[-2].numero.tipo, yyval.numero.tipo);
					ampliar(dir2, yystack.l_mark[0].numero.numeroCaracter, yystack.l_mark[0].numero.tipo, yyval.numero.tipo);
					printf("\n%s = %s * %s\n", yyval.numero.numeroCaracter, dir1, dir2);
			}
break;
case 61:
#line 632 "parse1.y"
	{
					char dir1[32], dir2[32];
					nuevaTemporal(yyval.numero.numeroCaracter);
					yyval.numero.tipo = max(yystack.l_mark[-2].numero.tipo, yystack.l_mark[0].numero.tipo);
					ampliar(dir1, yystack.l_mark[-2].numero.numeroCaracter, yystack.l_mark[-2].numero.tipo, yyval.numero.tipo);
					ampliar(dir2, yystack.l_mark[0].numero.numeroCaracter, yystack.l_mark[0].numero.tipo, yyval.numero.tipo);
					printf("\n%s = %s / %s\n", yyval.numero.numeroCaracter, dir1, dir2);
			}
break;
case 62:
#line 641 "parse1.y"
	{
					if(yystack.l_mark[-2].numero.tipo == 0 && yystack.l_mark[0].numero.tipo == 0){
						char dir1[32], dir2[32];
						nuevaTemporal(yyval.numero.numeroCaracter);
						yyval.numero.tipo = max(yystack.l_mark[-2].numero.tipo, yystack.l_mark[0].numero.tipo);
						ampliar(dir1, yystack.l_mark[-2].numero.numeroCaracter, yystack.l_mark[-2].numero.tipo, yyval.numero.tipo);
						ampliar(dir2, yystack.l_mark[0].numero.numeroCaracter, yystack.l_mark[0].numero.tipo, yyval.numero.tipo);
						printf("\n%s = %s + %s\n", yyval.numero.numeroCaracter, dir1, dir2);
					}else{
						yyerror("Ambos números deben ser enteros");
					}
				}
break;
case 63:
#line 654 "parse1.y"
	{
				yyval.numero = yystack.l_mark[-1].numero;
			
			}
break;
case 64:
#line 659 "parse1.y"
	{
				yyval.numero.tipo = yystack.l_mark[0].variable.tipo;
				strcpy(yyval.numero.numeroCaracter,yystack.l_mark[0].variable.dir);
			}
break;
case 65:
#line 663 "parse1.y"
	{yyval.numero = yystack.l_mark[0].numero;}
break;
case 66:
#line 664 "parse1.y"
	{yyval.numero = yystack.l_mark[0].numero;}
break;
case 67:
#line 665 "parse1.y"
	{yyval.numero = yystack.l_mark[0].numero;}
break;
case 68:
#line 669 "parse1.y"
	{
										yyval.variable.tipo = yystack.l_mark[0].variable_comp.tipo;
										strcpy(yyval.variable.estructura,"false");
										strcpy(yyval.variable.dir,"");
										yyval.variable.base = baseGBL;
										if(!getID(&generalSimbolos, yystack.l_mark[-1].id)){
					                    	yyerror("El id no fue declarado");
										}
								}
break;
case 69:
#line 680 "parse1.y"
	{
					yyval.variable_comp.tipo = yystack.l_mark[0].dato_est_sim.tipo;
					strcpy(yyval.variable_comp.estructura,yystack.l_mark[0].dato_est_sim.estructura);
					strcpy(yyval.variable_comp.dir,"");
				}
break;
case 70:
#line 686 "parse1.y"
	{
					yyval.variable_comp.tipo = yystack.l_mark[0].arreglo.tipo;
					strcpy(yyval.variable_comp.estructura,"false");
					strcpy(yyval.variable_comp.dir,yystack.l_mark[0].arreglo.dir);
				}
break;
case 71:
#line 692 "parse1.y"
	{
					yyval.variable_comp.tipo = tipoGBL;
					strcpy(yyval.variable_comp.estructura,"false");
					strcpy(yyval.variable_comp.dir,"");

				}
break;
case 72:
#line 700 "parse1.y"
	{
				if(!getID(&generalSimbolos, yystack.l_mark[0].id)){
					    yyerror("El id no fue declarado");
				}
					strcpy(yyval.dato_est_sim.estructura,"false");
					yyval.dato_est_sim.tipo = tipoGBL;
				
			}
break;
case 73:
#line 709 "parse1.y"
	{
				strcpy(yyval.dato_est_sim.estructura,"false");
				yyval.dato_est_sim.tipo = tipoGBL;
			}
break;
case 74:
#line 715 "parse1.y"
	{
			strcpy(yyval.arreglo.dir,yystack.l_mark[-1].numero.numeroCaracter);
			yyval.arreglo.tipo = yystack.l_mark[-1].numero.tipo;
		}
break;
case 75:
#line 720 "parse1.y"
	{
			strcpy(yyval.arreglo.dir,yystack.l_mark[-1].numero.numeroCaracter);
			yyval.arreglo.tipo = tipoGBL;
		}
break;
case 76:
#line 726 "parse1.y"
	{
				strcpy(yyval.lista_param.lista,yystack.l_mark[0].lista_param.lista);
				yyval.lista_param.num = yystack.l_mark[0].lista_param.num;
			}
break;
case 77:
#line 731 "parse1.y"
	{
				strcpy(yyval.lista_param.lista, "NULO");
				yyval.lista_param.num = 0;
			}
break;
case 78:
#line 738 "parse1.y"
	{
				strcpy(yyval.lista_param.lista, "");
				sprintf(yyval.lista_param.lista, "%d", yystack.l_mark[0].numero.tipo);
				yyval.lista_param.num = yystack.l_mark[-2].lista_param.num + 1;
			}
break;
case 79:
#line 744 "parse1.y"
	{
				strcpy(yyval.lista_param.lista, "");
				sprintf(yyval.lista_param.lista, "%d", yystack.l_mark[0].numero.tipo);
				yyval.lista_param.num = 1;
			}
break;
#line 1531 "y.tab.c"
    }
    yystack.s_mark -= yym;
    yystate = *yystack.s_mark;
    yystack.l_mark -= yym;
    yym = yylhs[yyn];
    if (yystate == 0 && yym == 0)
    {
#if YYDEBUG
        if (yydebug)
            printf("%sdebug: after reduction, shifting from state 0 to\
 state %d\n", YYPREFIX, YYFINAL);
#endif
        yystate = YYFINAL;
        *++yystack.s_mark = YYFINAL;
        *++yystack.l_mark = yyval;
        if (yychar < 0)
        {
            if ((yychar = YYLEX) < 0) yychar = YYEOF;
#if YYDEBUG
            if (yydebug)
            {
                yys = yyname[YYTRANSLATE(yychar)];
                printf("%sdebug: state %d, reading %d (%s)\n",
                        YYPREFIX, YYFINAL, yychar, yys);
            }
#endif
        }
        if (yychar == YYEOF) goto yyaccept;
        goto yyloop;
    }
    if ((yyn = yygindex[yym]) && (yyn += yystate) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yystate)
        yystate = yytable[yyn];
    else
        yystate = yydgoto[yym];
#if YYDEBUG
    if (yydebug)
        printf("%sdebug: after reduction, shifting from state %d \
to state %d\n", YYPREFIX, *yystack.s_mark, yystate);
#endif
    if (yystack.s_mark >= yystack.s_last && yygrowstack(&yystack) == YYENOMEM)
    {
        goto yyoverflow;
    }
    *++yystack.s_mark = (YYINT) yystate;
    *++yystack.l_mark = yyval;
    goto yyloop;

yyoverflow:
    YYERROR_CALL("yacc stack overflow");

yyabort:
    yyfreestack(&yystack);
    return (1);

yyaccept:
    yyfreestack(&yystack);
    return (0);
}
